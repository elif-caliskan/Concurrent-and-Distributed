Question 1 is the Pnueli algorithm. Mutual exclusion, unbounded overtaking and infinitely often properties are hold. 
How to run: (I couldn't install ispin in Windows so I tried it in my friend's computer) 
java -jar jspin.jar //to open jspin
Then, in jspin the pml file is opened, checked and verified
To verify each ltl, run this command:
./pan -N mutex
./pan -N unbounded1
./pan -N unbounded2
./pan -N inf1
./pan -N inf2

Question 2 has one png and one pdf file. Part A is the four layers of given graph. Part B is validations of given formulas. 

Question 3 is not completed since I couldn't install Road Runner.