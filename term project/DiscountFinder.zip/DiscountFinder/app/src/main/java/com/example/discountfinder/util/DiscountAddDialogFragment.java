package com.example.discountfinder.util;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.example.discountfinder.R;

public class DiscountAddDialogFragment extends DialogFragment {
    EditText productNameEdit;
    TextView discountValText;
    SeekBar discountSeekbar;
    int discountVal;

    public interface DiscountAddListener {
        public void onDialogPositiveClick(String product, int discount);
    }
    // Use this instance of the interface to deliver action events
    DiscountAddListener listener;

    // Override the Fragment.onAttach() method to instantiate the NoticeDialogListener
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            listener = (DiscountAddListener) context;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException(getActivity().toString()
                    + " must implement NoticeDialogListener");
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Build the dialog and set up the button click handlers
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View view = inflater.inflate(R.layout.layout_add_discount, null);
        productNameEdit = view.findViewById(R.id.discount_productName_editText);
        discountSeekbar = view.findViewById(R.id.discount_seekbar);
        discountValText = view.findViewById(R.id.discount_discountVal_text);
        discountSeekbar.setMax(100);
        discountSeekbar.setProgress(0);
        discountSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                discountVal = i;
                discountValText.setText("Discount value: %"+i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        builder.setView(view)
                // Add action buttons
                .setPositiveButton("Add to Store", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // sign in the user ...
                        listener.onDialogPositiveClick(productNameEdit.getText().toString(), discountVal);

                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        DiscountAddDialogFragment.this.getDialog().cancel();
                    }
                });
        return builder.create();
    }
}
