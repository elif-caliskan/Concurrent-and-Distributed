package com.example.discountfinder.util;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.discountfinder.R;
import com.example.discountfinder.model.Discount;

public class DiscountAdapter extends RecyclerView.Adapter<DiscountAdapter.ViewHolder>{
    private Discount[] listdata;
    private OnDiscountDeleted onDiscountDeleted;
    private boolean isRetailer;

    // RecyclerView recyclerView;
    public DiscountAdapter(Discount[] listdata, OnDiscountDeleted onDiscountDeleted, boolean isRetailer) {
        this.listdata = listdata;
        this.onDiscountDeleted = onDiscountDeleted;
        this.isRetailer = isRetailer;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.layout_discount_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.nameTextView.setText(listdata[position].discountProduct);
        holder.discountTextView.setText("Discount: %"+listdata[position].discountPercent);
        if(!isRetailer){
            holder.deleteButton.setVisibility(View.GONE);
        }
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onDiscountDeleted.onDiscountDeleted(position);
            }
        });
    }

    public void setDataset(Discount[] listdata){
        this.listdata = listdata;
    }


    @Override
    public int getItemCount() {
        return listdata.length;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView discountTextView;
        ImageView deleteButton;
        ConstraintLayout constraintLayout;

        ViewHolder(View itemView) {
            super(itemView);
            this.nameTextView = itemView.findViewById(R.id.product_name);
            this.discountTextView = itemView.findViewById(R.id.product_discount);
            this.constraintLayout = itemView.findViewById(R.id.item_background);
            this.deleteButton = itemView.findViewById(R.id.discount_delete);
        }
    }

    public interface OnDiscountDeleted {
        void onDiscountDeleted(int position);
    }
}