package com.example.discountfinder.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.discountfinder.R;
import com.example.discountfinder.model.Discount;
import com.example.discountfinder.model.Store;
import com.example.discountfinder.util.DiscountAdapter;
import com.example.discountfinder.util.DiscountAddDialogFragment;
import com.example.discountfinder.util.MessageSender;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.concurrent.ExecutionException;

public class DiscountActivity extends AppCompatActivity implements DiscountAdapter.OnDiscountDeleted, DiscountAddDialogFragment.DiscountAddListener
{
    Discount[] discounts;
    String storeJson;
    FloatingActionButton floatingActionButton;
    Gson gson;
    RecyclerView recyclerView;
    private boolean isRetailer;
    Store store;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discount);
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("M/d/yy hh:mm a");
        gson= gsonBuilder.create();

        Intent intent = getIntent();
        storeJson = intent.getStringExtra("storeJson");
        String type = intent.getStringExtra("type");
        isRetailer = type.equals("retailer");
        store = gson.fromJson(storeJson, Store.class);
        TextView text = findViewById(R.id.discount_in);
        text.setText("Discounts in "+ store.storeName);
        initdataset();

        recyclerView = findViewById(R.id.discount_recyclerView);

        recyclerView.setAdapter(new DiscountAdapter(discounts,  this, isRetailer));
        floatingActionButton = findViewById(R.id.fab_addDiscount);
        if(!isRetailer){
            floatingActionButton.setVisibility(View.GONE);
        }
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DiscountActivity.this, "Add new discount", Toast.LENGTH_SHORT).show();
                DialogFragment dialog = new DiscountAddDialogFragment();
                dialog.show(getSupportFragmentManager(), "NoticeDialogFragment");
            }
        });

    }

    @Override
    public void onDiscountDeleted(int position) {

        MessageSender messageSender = new MessageSender();
        try {
            String x = gson.toJson(discounts[position]);
            String result = messageSender.execute("107"+ x).get();
            if(result.equals("107")){
                Toast.makeText(DiscountActivity.this, "Your discount is deleted", Toast.LENGTH_SHORT).show();
                initdataset();

                DiscountAdapter adp = (DiscountAdapter) recyclerView.getAdapter();
                adp.setDataset(discounts);
                recyclerView.getAdapter().notifyDataSetChanged();
            }
            else{
                Toast.makeText(DiscountActivity.this, "Your discount is not deleted", Toast.LENGTH_SHORT).show();
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
            Toast.makeText(DiscountActivity.this, "Your discount is not added", Toast.LENGTH_SHORT).show();
        } catch (InterruptedException e) {
            e.printStackTrace();
            Toast.makeText(DiscountActivity.this, "Your discount is not added", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDialogPositiveClick(String product, int discount) {

        Discount discount1 = new Discount(product, discount, store.storeId);
        MessageSender messageSender = new MessageSender();
        try {
            String k = gson.toJson(discount1);
            String result = messageSender.execute("102"+ k).get();
            String first = result.substring(0,3);
            if(first.equals("102")){
                Toast.makeText(DiscountActivity.this, "Your discount is added", Toast.LENGTH_SHORT).show();
                initdataset();

                DiscountAdapter adp = (DiscountAdapter) recyclerView.getAdapter();
                adp.setDataset(discounts);
                recyclerView.getAdapter().notifyDataSetChanged();
            }
            else{
                Toast.makeText(DiscountActivity.this, "Your discount is not added", Toast.LENGTH_SHORT).show();
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
            Toast.makeText(DiscountActivity.this, "Your discount is not added", Toast.LENGTH_SHORT).show();
        } catch (InterruptedException e) {
            e.printStackTrace();
            Toast.makeText(DiscountActivity.this, "Your discount is not added", Toast.LENGTH_SHORT).show();
        }
    }

    private void initdataset(){
        MessageSender sender = new MessageSender();
        try {
            String result = sender.execute("106" + storeJson).get();
            String first = result.substring(0, 3);
            result = result.substring(3);
            if(first.equals("106") && result.length()> 0){
                try {
                    Object object =  new JSONParser().parse(result);
                    JSONArray jsonArray = (JSONArray)object;
                    int size = jsonArray.size();
                    discounts = new Discount[size];
                    for( int i = 0; i< size ;i ++){
                        discounts[i] = gson.fromJson((String) jsonArray.get(i), Discount.class);
                    }

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
            else{
                discounts = new Discount[0];
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    Handler handler = new Handler();
    Runnable runnable;
    int delay = 3*1000; //Delay for 15 seconds.  One second = 1000 milliseconds.


    @Override
    protected void onResume() {
        //start handler as activity become visible

        handler.postDelayed( runnable = new Runnable() {
            public void run() {

                initdataset();

                DiscountAdapter adp = (DiscountAdapter) recyclerView.getAdapter();
                adp.setDataset(discounts);
                recyclerView.getAdapter().notifyDataSetChanged();
                handler.postDelayed(runnable, delay);
            }
        }, delay);

        super.onResume();
    }

    // If onPause() is not included the threads will double up when you
    // reload the activity
    @Override
    protected void onPause() {
        handler.removeCallbacks(runnable); //stop handler when activity not visible
        super.onPause();
    }
}