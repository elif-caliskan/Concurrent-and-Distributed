package com.example.discountfinder.model;

public class Discount {
    public String discountProduct;
    public int discountPercent;
    public int discountId = -1;
    public int storeId;

    public Discount(String product, int discountPercent) {
        this.discountProduct = product;
        this.discountPercent = discountPercent;
    }

    public Discount(String product, int discountPercent, int id) {
        this.discountProduct = product;
        this.discountPercent = discountPercent;
        this.storeId = id;
    }

    public Discount(int discountId) {
        this.discountId = discountId;
    }
}
