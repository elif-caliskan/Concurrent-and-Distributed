package com.example.discountfinder.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.discountfinder.R;
import com.example.discountfinder.model.Retailer;
import com.example.discountfinder.util.MessageSender;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.ExecutionException;

public class LoginActivity extends Activity {
    EditText userNameEdit;
    EditText passwordEdit;
    Button loginButton;
    TextView signUpText;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        userNameEdit = findViewById(R.id.login_userName);
        passwordEdit = findViewById(R.id.login_password);
        loginButton = findViewById(R.id.login_button);
        signUpText = findViewById(R.id.login_signup);
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("M/d/yy hh:mm a");
        final Gson gson = gsonBuilder.create();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(userNameEdit.getText().toString().trim().equals("")){
                    userNameEdit.setError("Please enter your username");
                }
                else if(passwordEdit.getText().toString().trim().equals("")){
                    passwordEdit.setError("Please enter your pasword");
                }
                else{
                    Retailer retailer = new Retailer(userNameEdit.getText().toString(), passwordEdit.getText().toString());
                    MessageSender messageSender = new MessageSender();
                    try {
                        String result  = messageSender.execute("103" + gson.toJson(retailer)).get();
                        String first = result.substring(0, 3);
                        result = result.substring(3);
                        if(first.equals("103")){
                            Intent intent = new Intent(LoginActivity.this, RetailerActivity.class);
                            intent.putExtra("retailerJson", result);
                            startActivity(intent);
                        }
                        else if(first.equals("404")){
                            Toast.makeText(LoginActivity.this, "Yor are not logged in", Toast.LENGTH_SHORT).show();
                        }
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                        Toast.makeText(LoginActivity.this, "Yor are not logged in", Toast.LENGTH_SHORT).show();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Toast.makeText(LoginActivity.this, "Yor are not logged in", Toast.LENGTH_SHORT).show();

                    }

                }
            }
        });

        signUpText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

    }

}