package com.example.discountfinder.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.ViewPager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.discountfinder.util.MessageSender;
import com.example.discountfinder.R;
import com.example.discountfinder.model.Store;
import com.example.discountfinder.util.StoreNameDialogFragment;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import static java.nio.charset.StandardCharsets.*;


/*
1)login for retail birden fazla retailer own edebilir
4) üstlerine tıklayınca add dicount veya del discount
5) add discount
6) serverda store oluşsun
7) her activity açılışında serverdan yerleri ve isimleri çeksin
8) üstüne tıklayınca see discounts butonu çıksın
 */

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, StoreNameDialogFragment.NoticeDialogListener {

    private GoogleMap mMap;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private String type = "";
    private Store store;
    private Location storeLocation;
    private Gson gson;
    private int retailerId;
    ArrayList<Store> stores = new ArrayList<>();
    private FloatingActionButton floatingActionSeeButton;
    private FloatingActionButton floatingActionAddButton;
    private Location lastKnownLocation;
    private Store selectedStore;
    private boolean search;
    MarkerOptions markerOptions;
    Marker marker;
    Button addNewStore;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == 1){
            if(grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                }
            }
        }
    }

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        floatingActionSeeButton = findViewById(R.id.map_eye);
        floatingActionAddButton = findViewById(R.id.map_add);
        mapFragment.getMapAsync(this);

        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("M/d/yy hh:mm a");
        gson = gsonBuilder.create();

        Intent intent = getIntent();
        type = intent.getStringExtra("type");
        String jsonStore = intent.getStringExtra("storeJson");
        search = intent.getBooleanExtra("search", false);
        retailerId = intent.getIntExtra("retailerId", -1);
        if(jsonStore!= null){
            store = gson.fromJson(jsonStore, Store.class);
        }

        addNewStore = findViewById(R.id.add_store);
        if(type.equals("guest") || store!=null || search){
            addNewStore.setVisibility(View.GONE);
        }

        addNewStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(storeLocation== null){
                    Toast.makeText(MapsActivity.this, "Please choose a place", Toast.LENGTH_SHORT).show();
                }
                else{
                    DialogFragment dialog = new StoreNameDialogFragment();
                    dialog.show(getSupportFragmentManager(), "NoticeDialogFragment");
                }
            }
        });
        if(search){
            floatingActionSeeButton.setVisibility(View.GONE);
        }

        floatingActionAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!selectedStore.retailerId.contains(retailerId)){
                    ownStore();
                }
            }
        });

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);

        locationManager = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                // Add a markerOptions in Sydney and move the camera
                if((type.equals("guest") || search) && location != null && lastKnownLocation!=null && lastKnownLocation.getLatitude() != location.getLatitude()
                        && lastKnownLocation.getLongitude()!= location.getLongitude()){
                    updateMap(location, "Your location");
                    lastKnownLocation = location;
                    getAllStores();
                }
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };
        if(Build.VERSION.SDK_INT < 23){
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }
        else {
            if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
            else{
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0,0,locationListener);

                lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if((type.equals("guest") || store == null || search) && lastKnownLocation != null){
                    updateMap(lastKnownLocation, "Your location");
                    if(type.equals("guest") || search){
                        getAllStores();
                    }
                }
                else if(store!= null){
                    Location storeLocation = new Location("");
                    storeLocation.setLongitude(store.storeLongitude);
                    storeLocation.setLatitude(store.storeLatitude);
                    updateMap(storeLocation, store.storeName);
                }
                else {
                    getAllStores();
                }
            }
        }

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener()
        {
            @Override
            public void onMapClick(LatLng arg0)
            {
                if(store == null && type.equals("retailer") && !search){
                    Location newLoc = new Location("");
                    newLoc.setLatitude(arg0.latitude);
                    newLoc.setLongitude(arg0.longitude);
                    marker.remove();
                    marker = mMap.addMarker(new MarkerOptions().position(new LatLng(newLoc.getLatitude(), newLoc.getLongitude())).title("Your new store"));
                    storeLocation = newLoc;
                }
            }
        });

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @SuppressLint("RestrictedApi")
            @Override
            public boolean onMarkerClick(Marker marker) {
                if(marker.getTag()!=null){
                    int tag = (int) marker.getTag();
                    selectedStore = stores.get(tag);
                    //restricted api???
                    if(!search){
                        floatingActionSeeButton.setVisibility(View.VISIBLE);
                    }
                    else if(!selectedStore.retailerId.contains(retailerId)){
                        floatingActionAddButton.setVisibility(View.VISIBLE);
                    }
                    else{
                        floatingActionAddButton.setVisibility(View.GONE);
                    }
                }
                else{
                    floatingActionSeeButton.setVisibility(View.GONE);
                    floatingActionAddButton.setVisibility(View.GONE);
                }

                return false;
            }
        });

        floatingActionSeeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MapsActivity.this, DiscountActivity.class);
                intent.putExtra("storeJson",  gson.toJson(selectedStore));
                intent.putExtra("type", "guest");
                startActivity(intent);
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onDialogPositiveClick(String name) {

        String address = getAddress(storeLocation);
        Log.i("addresss ", address);
        Store message = new Store(storeLocation.getLatitude(), storeLocation.getLongitude(), name, address);
        message.retailerId.add(retailerId);
        sendStore(message);
        finish();

    }

    private void updateMap(Location location, String description){
        LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
        if(markerOptions ==null){
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15));
        }
        else{
            marker.remove();
        }
        markerOptions = new MarkerOptions().position(userLocation).title(description);
        marker = mMap.addMarker(markerOptions);
        storeLocation = location;
    }

    public void sendStore(Store message){
        MessageSender messageSender = new MessageSender();
        try {
            String result = messageSender.execute("101"+gson.toJson(message)).get();
            if(result.equals("101")){
                Toast.makeText(MapsActivity.this, "Your store is added ", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(MapsActivity.this, "Your store is not added ", Toast.LENGTH_SHORT).show();
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
            Toast.makeText(MapsActivity.this, "Your store is not added ", Toast.LENGTH_SHORT).show();

        } catch (InterruptedException e) {
            e.printStackTrace();
            Toast.makeText(MapsActivity.this, "Your store is not added ", Toast.LENGTH_SHORT).show();

        }
    }

    public void ownStore(){
        MessageSender messageSender = new MessageSender();
        try {
            String result = messageSender.execute("109"+gson.toJson(selectedStore) + "#" + retailerId).get();
            if(result.equals("109")){
                Toast.makeText(MapsActivity.this, "Your store is added ", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(MapsActivity.this, "Your store is not added ", Toast.LENGTH_SHORT).show();
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
            Toast.makeText(MapsActivity.this, "Your store is not added ", Toast.LENGTH_SHORT).show();

        } catch (InterruptedException e) {
            e.printStackTrace();
            Toast.makeText(MapsActivity.this, "Your store is not added ", Toast.LENGTH_SHORT).show();

        }
    }

    public void getAllStores(){
        MessageSender sender = new MessageSender();
        try {
            String storesJson = sender.execute("104").get();
            String first = storesJson.substring(0, 3);
            storesJson = storesJson.substring(3);
            if(first.equals("104") && storesJson.length()>0){
                Object object;
                stores.clear();
                try {
                    object = new JSONParser().parse(storesJson);
                    JSONArray jsonArray = (JSONArray)object;
                    int size = jsonArray.size();
                    for( int i = 0; i< size ;i ++){
                        stores.add(gson.fromJson((String) jsonArray.get(i), Store.class));
                    }
                    if(!search && addNewStore.getVisibility() != View.VISIBLE){
                        showAllStores();
                    }else if(addNewStore.getVisibility() != View.VISIBLE){
                        getStoresOf();
                    }
                }
                catch (ParseException e) {
                    e.printStackTrace();
                }
            }

        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void showAllStores(){
        mMap.clear();
        if(markerOptions!=null){
            mMap.addMarker(markerOptions);
        }
        for(int i = 0;i < stores.size();i++){
            Store s = stores.get(i);
            Marker marker = mMap.addMarker(new MarkerOptions()
                    .position(new LatLng( s.storeLatitude, s.storeLongitude))
                    .title(s.storeName)
                    .snippet(s.storeAddress)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
            marker.setTag(i);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public String getAddress(Location location){
        Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.ENGLISH);

        String address = "";

        try {
            List<Address> listAddress = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            if(listAddress!=null && listAddress.size()>0){
                Log.i("PlaceInfo", listAddress.get(0).toString());

                if(listAddress.get(0).getSubThoroughfare() != null){
                    address += listAddress.get(0).getSubThoroughfare()+ ", ";
                }
                if(listAddress.get(0).getThoroughfare() != null){
                    address+= listAddress.get(0).getThoroughfare()+ ", ";
                }
                if(listAddress.get(0).getLocality() != null){
                    address+= listAddress.get(0).getLocality()+", ";
                }
                if(listAddress.get(0).getPostalCode() != null){
                    address+= listAddress.get(0).getPostalCode()+", ";
                }
                if(listAddress.get(0).getCountryName()!=null){
                    address+= listAddress.get(0).getCountryName();
                }
                byte[] ptext = address.getBytes(ISO_8859_1);
                String value = new String(ptext, UTF_8);
                return value;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return address;

    }

    private void getStoresOf(){
        mMap.clear();
        if(markerOptions!=null){
            mMap.addMarker(markerOptions);
        }
        for(int i = 0;i<stores.size();i++){
            Store s = stores.get(i);
            if(s.retailerId.contains(retailerId)){
                Marker marker = mMap.addMarker(new MarkerOptions()
                        .position(new LatLng( s.storeLatitude, s.storeLongitude))
                        .title(s.storeName)
                        .snippet(s.storeAddress)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
                marker.setTag(i);
            }
            else{
                Marker marker = mMap.addMarker(new MarkerOptions()
                        .position(new LatLng( s.storeLatitude, s.storeLongitude))
                        .title(s.storeName)
                        .snippet(s.storeAddress)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA)));
                marker.setTag(i);
            }
        }
    }

    Handler handler = new Handler();
    Runnable runnable;
    int delay = 3*1000; //Delay for 15 seconds.  One second = 1000 milliseconds.


    @Override
    protected void onResume() {
        //start handler as activity become visible

        handler.postDelayed( runnable = new Runnable() {
            public void run() {
                if(storeLocation==null){
                    getAllStores();
                }
                handler.postDelayed(runnable, delay);
            }
        }, delay);

        super.onResume();
    }

    // If onPause() is not included the threads will double up when you
    // reload the activity
    @Override
    protected void onPause() {
        handler.removeCallbacks(runnable); //stop handler when activity not visible
        super.onPause();
    }

}