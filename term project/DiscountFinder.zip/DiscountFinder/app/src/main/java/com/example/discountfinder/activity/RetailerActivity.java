package com.example.discountfinder.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.example.discountfinder.R;
import com.example.discountfinder.model.Retailer;
import com.example.discountfinder.util.MessageSender;
import com.example.discountfinder.util.StoreAdapter;
import com.example.discountfinder.model.Store;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.concurrent.ExecutionException;

/*
2) discount ekleme vs
2) direkt üstüne basınca discountları göstersin o sayfada discount ekleme vs
4) ortak sahipler olabilir!!
 */
public class RetailerActivity extends Activity implements StoreAdapter.OnStoreMapClicked, StoreAdapter.OnStoreClicked, StoreAdapter.OnStoreDeleted {
    FloatingActionButton floatingActionAddButton;
    FloatingActionButton floatingActionSearchButton;
    Store[] stores;
    Retailer retailer;
    Gson gson;
    String retailerStr;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retailer);

        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("M/d/yy hh:mm a");
        gson = gsonBuilder.create();

        Intent intent = getIntent();
        retailerStr = intent.getExtras().getString("retailerJson");
        retailer = gson.fromJson(retailerStr, Retailer.class);

        recyclerView = findViewById(R.id.retailer_recyclerView);
        TextView textView = findViewById(R.id.retailer_welcome);
        textView.setText("Welcome "+ retailer.retailerName);

        initdataset();

        recyclerView.setAdapter(new StoreAdapter(stores, this, this, this));
        floatingActionAddButton = findViewById(R.id.fab_addStore);
        floatingActionAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RetailerActivity.this, MapsActivity.class);
                intent.putExtra("type", "retailer");
                intent.putExtra("retailerId", retailer.retailerId);
                startActivity(intent);
            }
        });

        floatingActionSearchButton = findViewById(R.id.retailer_search);
        //kendi storeların farklı renk olsun
        //ownerlık bırakma olsun sadece biri yapabilsin
        // store silinecekse yine lock olmalı
        floatingActionSearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RetailerActivity.this, MapsActivity.class);
                intent.putExtra("type", "retailer");
                intent.putExtra("search", true);
                intent.putExtra("retailerId", retailer.retailerId);
                startActivity(intent);
            }
        });

    }

    @Override
    public void onStoreMapClicked(int position) {
        Intent intent = new Intent(RetailerActivity.this, MapsActivity.class);
        intent.putExtra("storeJson", gson.toJson(stores[position]));
        intent.putExtra("type", "retailer");
        startActivity(intent);
    }

    @Override
    public void onStoreClicked(int position) {
        Intent intent = new Intent(RetailerActivity.this, DiscountActivity.class);
        intent.putExtra("storeJson",  gson.toJson(stores[position]));
        intent.putExtra("type", "retailer");
        startActivity(intent);
    }

    @Override
    protected void onResume() {

        initdataset();
        StoreAdapter adp = (StoreAdapter)recyclerView.getAdapter();
        adp.setDataset(stores);
        recyclerView.getAdapter().notifyDataSetChanged();
        super.onResume();
    }

    private void initdataset(){
        MessageSender sender = new MessageSender();
        try {
            String result = sender.execute("105" + retailerStr).get();
            String first = result.substring(0, 3);
            result = result.substring(3);
            if(first.equals("105") && result.length()> 0){
                try {
                    Object object =  new JSONParser().parse(result);
                    JSONArray jsonArray = (JSONArray)object;
                    int size = jsonArray.size();
                    stores = new Store[size];
                    for( int i = 0; i< size ;i ++){
                        stores[i] = gson.fromJson((String) jsonArray.get(i), Store.class);
                    }

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
            else{
                stores = new Store[0];
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onStoreDeleted(int position) {

        MessageSender sender = new MessageSender();
        try {
            String x = gson.toJson(stores[position]);
            String result = sender.execute("108"+ x + "#"+ retailer.retailerId).get();
            if(result.equals("108")){
                initdataset();
                StoreAdapter adp = (StoreAdapter)recyclerView.getAdapter();
                adp.setDataset(stores);
                recyclerView.getAdapter().notifyDataSetChanged();
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}