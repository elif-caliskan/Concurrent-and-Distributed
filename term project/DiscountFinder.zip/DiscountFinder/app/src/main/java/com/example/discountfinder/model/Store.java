package com.example.discountfinder.model;

import java.util.ArrayList;

public class Store {

    public int storeId = -1;
    public double storeLatitude;
    public double storeLongitude;
    public String storeName;
    public String storeAddress;
    public ArrayList<Integer> retailerId = new ArrayList<>();

    public Store(double latitude, double longitude, String name, String address){
        this.storeLatitude = latitude;
        this.storeLongitude = longitude;
        this.storeName = name;
        this.storeAddress =address;
    }

    Store(int id, double latitude, double longitude, String name, String address) {
        this.storeLatitude = latitude;
        this.storeLongitude = longitude;
        this.storeName = name;
        this.storeId = id;
        this.storeAddress = address;
    }
}

