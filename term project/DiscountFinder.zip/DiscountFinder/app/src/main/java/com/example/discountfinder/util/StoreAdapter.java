package com.example.discountfinder.util;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.discountfinder.R;
import com.example.discountfinder.model.Store;

public class StoreAdapter extends RecyclerView.Adapter<StoreAdapter.ViewHolder>{
    private Store[] listdata;
    private OnStoreClicked storeClicked;
    private OnStoreMapClicked storeMapClicked;
    private OnStoreDeleted storeDeleted;

    // RecyclerView recyclerView;
    public StoreAdapter(Store[] listdata, OnStoreClicked storeClicked, OnStoreMapClicked storeMapClicked, OnStoreDeleted onStoreDeleted) {
        this.listdata = listdata;
        this.storeClicked = storeClicked;
        this.storeMapClicked = storeMapClicked;
        this.storeDeleted = onStoreDeleted;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.layout_store_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.nameTextView.setText(listdata[position].storeName);
        holder.addressTextView.setText(listdata[position].storeAddress);
        holder.constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                storeClicked.onStoreClicked(position);
            }
        });
        holder.locationImageView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                storeMapClicked.onStoreMapClicked(position);
            }
        });
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                storeDeleted.onStoreDeleted(position);
            }
        });
    }


    @Override
    public int getItemCount() {
        return listdata.length;
    }
    public void setDataset(Store[] listdata){
        this.listdata = listdata;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView addressTextView;
        ImageView locationImageView;
        ConstraintLayout constraintLayout;
        ImageView deleteButton;

        ViewHolder(View itemView) {
            super(itemView);
            this.nameTextView = itemView.findViewById(R.id.retailer_store_name);
            this.addressTextView = itemView.findViewById(R.id.retailer_store_address);
            this.locationImageView = itemView.findViewById(R.id.location_icon);
            this.constraintLayout = itemView.findViewById(R.id.item_background);
            this.deleteButton = itemView.findViewById(R.id.store_delete);
        }
    }
    public interface OnStoreMapClicked{
        void onStoreMapClicked(int position);
    }

    public interface OnStoreClicked{
        void onStoreClicked(int position);
    }

    public interface OnStoreDeleted{
        void onStoreDeleted(int position);
    }

}  