package com.example.discountfinder.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.discountfinder.R;
import com.example.discountfinder.model.Retailer;
import com.example.discountfinder.util.MessageSender;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.ExecutionException;

public class SignupActivity extends Activity {
    EditText userNameEdit;
    EditText passwordEdit;
    EditText emailEdit;
    Button signupButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        userNameEdit = findViewById(R.id.signup_userName);
        passwordEdit = findViewById(R.id.signup_password);
        signupButton = findViewById(R.id.signup_button);
        emailEdit = findViewById(R.id.signup_email);
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("M/d/yy hh:mm a");
        final Gson gson = gsonBuilder.create();

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(emailEdit.getText().toString().trim().equals("")){
                    emailEdit.setError("Please enter your email");
                }
                else if(userNameEdit.getText().toString().trim().equals("")){
                    userNameEdit.setError("Please enter your username");
                }
                else if(passwordEdit.getText().toString().trim().equals("")){
                    passwordEdit.setError("Please enter your pasword");
                }
                else{
                    Retailer retailer = new Retailer(emailEdit.getText().toString(), userNameEdit.getText().toString(), passwordEdit.getText().toString());
                    MessageSender messageSender = new MessageSender();
                    try {
                        String result = messageSender.execute("100" + gson.toJson(retailer)).get();
                        if(result.equals("100")){
                            Toast.makeText(SignupActivity.this, "You are registered", Toast.LENGTH_SHORT).show();
                            finish();
                        }

                    } catch (ExecutionException e) {
                        e.printStackTrace();
                        Toast.makeText(SignupActivity.this, "You are not registered", Toast.LENGTH_SHORT).show();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Toast.makeText(SignupActivity.this, "You are not registered", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }

}