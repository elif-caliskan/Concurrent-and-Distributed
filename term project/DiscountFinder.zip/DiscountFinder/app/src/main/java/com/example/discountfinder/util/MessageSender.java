package com.example.discountfinder.util;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class MessageSender extends AsyncTask<String, Void, String> {

    Socket s;
    DataOutputStream dos;
    PrintWriter pw;
    InputStreamReader isr;
    BufferedReader br;

    @Override
    protected String doInBackground(String... voids) {
        String message = voids[0];
        try {
            Log.i("amessage1", message);
            s = new Socket("3.125.41.217", 6000);
            pw = new PrintWriter(s.getOutputStream());
            pw.write(message+"\n");
            pw.flush();
            //s.close();

            isr = new InputStreamReader(s.getInputStream());
            br = new BufferedReader(isr);
            message = br.readLine();
            String line = "";
            while ((line = br.readLine()) != null){
                message += line;
            }
            Log.i("amessage2", message);
            String first = message.substring(0, 3);
            switch (first) {
                case "100":
                    return "100";
                case "101":
                    return "101";
                case "102":
                    return "102";
                case "103":
                    return message;
                case "404":
                    return "404";
                case "105":
                    return message;
                case "106":
                    return message;
                case "107":
                    return "107";
                case "108":
                    return "108";
                case "104":
                    return message;
                case "109":
                    return "109";
            }
            pw.close();
            br.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}